//Arabic
export default {
  homePage: {
    Subtitle: "Discover the Unesco World Heritage with a Historian Guide",
    RedeemCode: "Redeem Code",
    BuyTour: "Buy Tour",
    PurchaseCode: "Purchase Code",
    FreeTour: "Free Tour"
  },
  customDropDown: {
    SelectLanguage: "Select Language",
    Close: "Close"
  },
  redeemPage: {
    Subtitle: "Discover the Unesco World Heritage with a Historian Guide",
    RedeemCode: "Redeem Code",
    EnterCode: "Enter Code",
    SubmitCode: "Submit Code"
  },
  loadingPage: {
    Subtitle: "Discover the Unesco World Heritage with a Historian Guide",
    MainTitle: "Downloading \ncontent",
    MainTitle2: "Download Language \nText and Audio Content"
  },
  mediaScreen: {
    Garden: "Garden",
    FirstFloor: "1st floor",
    SecondFloor: "2nd floor"
  }
};
